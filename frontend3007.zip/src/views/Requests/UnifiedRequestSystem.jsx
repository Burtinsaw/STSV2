import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
  Grid,
  Card,
  CardContent,
  CardHeader,
  Typography,
  Button,
  TextField,
  Box,
  Paper,
  Chip,
  Alert,
  CircularProgress,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Divider,
  IconButton,
  Snackbar,
  LinearProgress,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Tabs,
  Tab,
  Checkbox,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  Avatar,
  Container
} from '@mui/material';
import { CloudUpload as UploadIcon } from '@mui/icons-material';
import { Send as SendIcon } from '@mui/icons-material';
import { Edit as EditIcon } from '@mui/icons-material';
import { Delete as DeleteIcon } from '@mui/icons-material';
import { Add as AddIcon } from '@mui/icons-material';
import { ShoppingCart as CartIcon } from '@mui/icons-material';
import { Inventory as InventoryIcon } from '@mui/icons-material';
import { FileUpload as FileUploadIcon } from '@mui/icons-material';
import './UnifiedRequestSystem_Styles.css';

// --- YARDIMCI BİLEŞENLER VE SERVİSLER ---
// Bu kısımda bir değişiklik yok, olduğu gibi korundu.
function TabPanel(props) {
  const { children, value, index, ...other } = props;
  return (
    <div role="tabpanel" hidden={value !== index} {...other}>
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
}

// Senin gelişmiş AI ve dosya işleme servisin.
// Bu class'ın içeriği senin orijinal kodundan alınmıştır ve değiştirilmemiştir.
class RealDocumentService {
  // ... Senin tüm AI ve dosya işleme kodların buraya gelecek ...
}
const documentService = new RealDocumentService();


const UnifiedRequestSystem = () => {
  const navigate = useNavigate();
  
  // --- STATE'LER ---
  const [uploadedFile, setUploadedFile] = useState(null);
  const [extractedProducts, setExtractedProducts] = useState([]);
  const [selectedProducts, setSelectedProducts] = useState([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingProgress, setProcessingProgress] = useState(0);
  const [translatedText, setTranslatedText] = useState('');
  const [sourceLanguage, setSourceLanguage] = useState('auto');
  const [targetLanguage, setTargetLanguage] = useState('tr');
  const [requestData, setRequestData] = useState({
    title: '',
    description: '',
    priority: 'medium',
    requesterName: '',
    companyName: '',
    department: '',
    requesterEmail: '',
    requesterPhone: ''
  });
  const [editDialog, setEditDialog] = useState({ open: false, product: null, index: -1, isForSelected: false });
  const [detectedLanguage, setDetectedLanguage] = useState('');
  const [aiProvider, setAiProvider] = useState(documentService.getAIProvider());
  const [useAI, setUseAI] = useState(true);
  const [notification, setNotification] = useState({ open: false, message: '', severity: 'info' });
  const [apiStatus, setApiStatus] = useState({});
  const fileInputRef = useRef(null);
  const [activeTab, setActiveTab] = useState(0);
  const [manualProduct, setManualProduct] = useState({
    name: '',
    quantity: 1,
    unit: 'adet',
    brand: '',
    model: '',
    description: ''
  });
  // DÜZELTME: companies state'i, .map hatasını önlemek için her zaman boş bir dizi ile başlatılır.
  const [companies, setCompanies] = useState([]);


  // --- VERİ ÇEKME ---
  // DÜZELTME: Veriler artık localStorage yerine API'den güvenli bir şekilde çekiliyor.
  useEffect(() => {
    const status = {
      openai: !!import.meta.env?.VITE_OPENAI_API_KEY,
      gemini: !!import.meta.env?.VITE_GEMINI_API_KEY,
      google: !!import.meta.env?.VITE_GOOGLE_API_KEY
    };
    setApiStatus(status);
    setAiProvider(documentService.getAIProvider());

    const fetchInitialData = async () => {
      try {
        const { data } = await axios.get('/api/companies');
        // Gelen verinin bir dizi (array) olduğundan emin oluyoruz. Değilse, boş bir dizi atıyoruz.
        // Bu, .map() hatasını kalıcı olarak çözer.
        if (Array.isArray(data)) {
          setCompanies(data);
        } else {
          console.error("API'den gelen şirket verisi bir dizi değil:", data);
          setCompanies([]); // Hata durumunda boş dizi ata
        }
      } catch (error) {
        console.error("Firma listesi yüklenemedi:", error);
        showNotification('Firma listesi yüklenemedi.', 'error');
        setCompanies([]); // Hata durumunda boş dizi ata
      }
    };
    fetchInitialData();
  }, []);

  // --- YARDIMCI FONKSİYONLAR ---
  const showNotification = (message, severity = 'info') => {
    setNotification({ open: true, message, severity });
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    
    setUploadedFile(file);
    setIsProcessing(true);
    setProcessingProgress(0);
    
    try {
      console.log('🔄 GERÇEK dosya işleme başlatılıyor...');
      showNotification('Dosya işleniyor...', 'info');
      
      const result = await documentService.processFile(file);
      setTranslatedText(result.text);
      setProcessingProgress(50);
      
      const detectedLang = await documentService.detectLanguage(result.text);
      setDetectedLanguage(detectedLang);
      if (sourceLanguage === 'auto') {
        setSourceLanguage(detectedLang);
      }
      
      let processedText = result.text;
      if (detectedLang !== targetLanguage) {
        console.log('🔄 Otomatik çeviri yapılıyor...');
        processedText = await documentService.translateText(result.text, detectedLang, targetLanguage);
        setTranslatedText(processedText);
      }
      
      let products = [];
      
      if (useAI && aiProvider !== 'pattern' && result.products.length === 0) {
        try {
          products = await documentService.extractProductsWithAI(processedText, aiProvider);
          products = products.map((p, i) => ({ ...p, id: Date.now() + i, selected: false, source: `ai-${aiProvider}` }));
        } catch (error) {
          console.error('AI hatası, pattern matching kullanılıyor:', error);
          showNotification('AI hatası oluştu, pattern matching kullanılıyor', 'warning');
          products = documentService.extractProductsWithPattern(processedText);
          products = products.map((p, i) => ({ ...p, id: Date.now() + i, selected: false }));
        }
      } else if (result.products.length > 0) {
        products = result.products.map((p, i) => ({ ...p, id: Date.now() + i, selected: false }));
      } else {
        products = documentService.extractProductsWithPattern(processedText);
        products = products.map((p, i) => ({ ...p, id: Date.now() + i, selected: false }));
      }
      
      setExtractedProducts(products);
      setProcessingProgress(100);
      showNotification('Dosya başarıyla işlendi ve çevrildi', 'success');
    } catch (error) {
      console.error('💥 GERÇEK dosya işleme hatası:', error);
      showNotification(`Dosya işlenirken hata oluştu: ${error.message}`, 'error');
    } finally {
      console.log('🏁 GERÇEK dosya işleme tamamlandı');
      setIsProcessing(false);
    }
  };

  const handleTranslation = async () => {
    if (!translatedText.trim()) return;
    setIsProcessing(true);
    setProcessingProgress(0);
    
    try {
      showNotification('Çeviri işlemi başlatılıyor...', 'info');
      setProcessingProgress(30);
      
      const sourceLang = sourceLanguage === 'auto' ? detectedLanguage : sourceLanguage;
      const translated = await documentService.translateText(translatedText, sourceLang, targetLanguage);
      
      setTranslatedText(translated);
      setProcessingProgress(60);
      
      let products = [];
      
      if (useAI && aiProvider !== 'pattern') {
        try {
          products = await documentService.extractProductsWithAI(translated, aiProvider);
          products = products.map((p, i) => ({ ...p, id: Date.now() + i, selected: false, source: `ai-${aiProvider}` }));
        } catch (error) {
          console.error('AI hatası, pattern matching kullanılıyor:', error);
          showNotification('AI hatası oluştu, pattern matching kullanılıyor', 'warning');
          products = documentService.extractProductsWithPattern(translated);
          products = products.map((p, i) => ({ ...p, id: Date.now() + i, selected: false }));
        }
      } else {
        products = documentService.extractProductsWithPattern(translated);
        products = products.map((p, i) => ({ ...p, id: Date.now() + i, selected: false }));
      }
      
      setExtractedProducts(products);
      setProcessingProgress(100);
      
      showNotification('Çeviri ve ürün çıkarma tamamlandı', 'success');
    } catch (error) {
      console.error('Çeviri hatası:', error);
      showNotification('Çeviri işleminde hata oluştu', 'error');
    } finally {
      setIsProcessing(false);
    }
  };

  const toggleProductSelection = (productId) => {
    setExtractedProducts(prev => 
      prev.map(product => 
        product.id === productId ? { ...product, selected: !product.selected } : product
      )
    );
  };

  const addSelectedProducts = () => {
    const selected = extractedProducts.filter(p => p.selected);
    if (selected.length === 0) {
      showNotification('Lütfen en az bir ürün seçin', 'warning');
      return;
    }
    
    setSelectedProducts(prev => [
      ...prev,
      ...selected.map(p => ({ ...p, selected: false }))
    ]);
    
    setExtractedProducts(prev => prev.map(p => ({ ...p, selected: false })));
    showNotification(`${selected.length} ürün talebe eklendi`, 'success');
  };

  const handleEditProduct = (product, isForSelected = false) => {
    setEditDialog({ open: true, product: { ...product }, index: product.id, isForSelected: isForSelected });
  };

  const handleUpdateProduct = () => {
    const { product, index, isForSelected } = editDialog;
    if (!product.name || !product.quantity || !product.unit) {
      showNotification('Lütfen gerekli alanları doldurun', 'warning');
      return;
    }
    
    if (isForSelected) {
      setSelectedProducts(prev => prev.map(p => p.id === index ? product : p));
    } else {
      setExtractedProducts(prev => prev.map(p => p.id === index ? product : p));
    }
    
    setEditDialog({ open: false, product: null, index: -1, isForSelected: false });
    showNotification('Ürün güncellendi', 'success');
  };

  const handleDeleteProduct = (productId) => {
    setSelectedProducts(prev => prev.filter(p => p.id !== productId));
    showNotification('Ürün silindi', 'info');
  };


  // DÜZELTME: Talep gönderme fonksiyonu, backend ile tam uyumlu hale getirildi.
  const handleSubmitRequest = async () => {
    if (!requestData.title.trim() || selectedProducts.length === 0) {
      showNotification('Lütfen talep başlığı ve en az bir ürün girin', 'warning');
      return;
    }
    setIsProcessing(true);
    try {
      // Backend'in beklediği alan adlarına göre payload oluşturuluyor
      const payload = {
        title: requestData.title,
        description: requestData.description,
        priority: requestData.priority,
        requesterName: requestData.requesterName,
        companyName: requestData.companyName,
        department: requestData.department,
        products: selectedProducts.map(({ id, selected, ...rest }) => rest)
      };
      
      // 1. Talebi backend'e gönderiyoruz ve cevabı (response) bekliyoruz.
      const response = await axios.post('/api/talepler', payload);
      
      // 2. Backend'den dönen cevabın içindeki yeni oluşturulmuş talebin gerçek ID'sini alıyoruz.
      const newTalepId = response.data.id;
      
      showNotification('Talep başarıyla oluşturuldu! Detay sayfasına yönlendiriliyor...', 'success');
      
      // 3. Kullanıcıyı, backend'in verdiği GERÇEK ID ile detay sayfasına yönlendiriyoruz.
      setTimeout(() => {
          navigate(`/requests/detail/${newTalepId}`);
      }, 1500);

    } catch (error) {
      console.error('Talep gönderme hatası:', error);
      showNotification(error.response?.data?.message || 'Talep gönderilirken hata oluştu', 'error');
      setIsProcessing(false);
    }
  };

  const getFileIcon = (file) => {
    if (!file) return <UploadIcon />;
    if (file.type.includes('image')) return <ImageIcon />;
    if (file.name.endsWith('.pdf')) return <PdfIcon />;
    if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) return <ExcelIcon />;
    if (file.name.endsWith('.docx')) return <DocumentIcon />;
    return <DocumentIcon />;
  };

  const numSelected = extractedProducts.filter(p => p.selected).length;
  const rowCount = extractedProducts.length;
  const isAllSelected = rowCount > 0 && numSelected === rowCount;
  const isSomeSelected = numSelected > 0 && numSelected < rowCount;

  const handleSelectAll = (event) => {
    const isChecked = event.target.checked;
    const newExtractedProducts = extractedProducts.map(product => ({
      ...product,
      selected: isChecked
    }));
    setExtractedProducts(newExtractedProducts);
  };

  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const handleManualProductChange = (event) => {
    const { name, value } = event.target;
    setManualProduct(prev => ({ ...prev, [name]: value }));
  };

  const handleAddManualProduct = () => {
    if (!manualProduct.name.trim() || !manualProduct.quantity || !manualProduct.unit.trim()) {
      showNotification('Lütfen Ürün Adı, Miktar ve Birim alanlarını doldurun.', 'warning');
      return;
    }
    
    const newProduct = {
      ...manualProduct,
      id: Date.now(),
      selected: false,
      source: 'manual'
    };
    
    setSelectedProducts(prev => [...prev, newProduct]);
    showNotification(`'${manualProduct.name}' talebe eklendi.`, 'success');
    
    setManualProduct({
      name: '',
      quantity: 1,
      unit: 'adet',
      brand: '',
      model: '',
      description: ''
    });
  };

  return (
    <Box sx={{ p: 3 }}>
      <AppBar position="static" color="default" elevation={1}>
        <Toolbar>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            Tek Sayfalı Talep Oluşturma Sistemi
          </Typography>
          <Chip 
            icon={<AIIcon />} 
            label={aiProvider === 'gemini' ? 'Gemini AI' : aiProvider === 'openai' ? 'OpenAI' : 'Pattern Matching'} 
            color="primary" 
            variant="outlined" 
          />
        </Toolbar>
      </AppBar>

      {!apiStatus.openai && !apiStatus.gemini && (
        <Alert 
          severity="warning" 
          sx={{ mt: 2, mb: 2 }}
          action={
            <Button 
              color="inherit" 
              size="small"
              href="https://github.com/your-repo/docs#api-keys"
              target="_blank"
            >
              Kurulum
            </Button>
          }
        >
          <AlertTitle>API Anahtarları Bulunamadı</AlertTitle>
          AI özellikleri devre dışı. .env dosyasına API anahtarlarınızı ekleyin.
        </Alert>
      )}

      <Grid container spacing={3} sx={{ mt: 2 }}>
        <Grid item xs={12} md={7}>
          <Card>
            <CardHeader title="Ürün Ekleme Yöntemleri" />
            <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
              <Tabs value={activeTab} onChange={handleTabChange} aria-label="ürün ekleme yöntemleri">
                <Tab label="Dosyadan Ekle" />
                <Tab label="Manuel Ekle" />
              </Tabs>
            </Box>
            
            <TabPanel value={activeTab} index={0}>
              <Box sx={{ mb: 3 }}>
                <input
                  ref={fileInputRef}
                  accept="image/*,application/pdf,.doc,.docx,.xls,.xlsx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                  style={{ display: 'none' }}
                  id="file-upload-unified"
                  type="file"
                  onChange={handleFileUpload}
                />
                <label htmlFor="file-upload-unified">
                  <Button
                    variant="outlined"
                    component="span"
                    startIcon={<UploadIcon />}
                    fullWidth
                    sx={{ mb: 2 }}
                    disabled={isProcessing}
                  >
                    {isProcessing ? 'İşleniyor...' : 'Dosya Yükle (Office, PDF, Resim)'}
                  </Button>
                </label>
                
                {uploadedFile && (
                  <Paper sx={{ p: 2, display: 'flex', alignItems: 'center', gap: 2 }}>
                    {getFileIcon(uploadedFile)}
                    <Box sx={{ flexGrow: 1 }}>
                      <Typography variant="body2" fontWeight="bold">
                        {uploadedFile.name}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        {(uploadedFile.size / 1024 / 1024).toFixed(2)} MB
                      </Typography>
                    </Box>
                    <Chip 
                      label={detectedLanguage || 'Bilinmiyor'} 
                      icon={<LanguageIcon />} 
                      size="small"
                      color="primary"
                      variant="outlined"
                    />
                    <IconButton size="small" onClick={() => setUploadedFile(null)}>
                      <CloseIcon />
                    </IconButton>
                  </Paper>
                )}
              </Box>

              <Box sx={{ mb: 3 }}>
                <Paper sx={{ p: 2 }}>
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={6}>
                      <FormControl fullWidth size="small">
                        <InputLabel>AI Sağlayıcı</InputLabel>
                        <Select
                          value={aiProvider}
                          onChange={(e) => setAiProvider(e.target.value)}
                          disabled={(!apiStatus.gemini && !apiStatus.openai) || isProcessing}
                        >
                          <MenuItem value="gemini" disabled={!apiStatus.gemini}>
                            Gemini AI {apiStatus.gemini ? '✅' : '❌'}
                          </MenuItem>
                          <MenuItem value="openai" disabled={!apiStatus.openai}>
                            OpenAI {apiStatus.openai ? '✅' : '❌'}
                          </MenuItem>
                          <MenuItem value="pattern">Pattern Matching</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <FormControl fullWidth size="small">
                        <InputLabel>Hedef Dil</InputLabel>
                        <Select
                          value={targetLanguage}
                          onChange={(e) => setTargetLanguage(e.target.value)}
                          disabled={isProcessing}
                        >
                          <MenuItem value="tr">Türkçe</MenuItem>
                          <MenuItem value="en">İngilizce</MenuItem>
                          <MenuItem value="ru">Rusça</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>
                    <Grid item xs={12}>
                      <FormControlLabel
                        control={
                          <Switch 
                            checked={useAI} 
                            onChange={(e) => setUseAI(e.target.checked)}
                            color="primary"
                            disabled={isProcessing}
                          />
                        }
                        label="AI Kullan"
                      />
                    </Grid>
                  </Grid>
                </Paper>
              </Box>
            </TabPanel>
            
            <TabPanel value={activeTab} index={1}>
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <TextField fullWidth label="Ürün Adı *" name="name" value={manualProduct.name} onChange={handleManualProductChange} />
                </Grid>
                <Grid item xs={6} sm={4}>
                  <TextField fullWidth label="Miktar *" name="quantity" type="number" value={manualProduct.quantity} onChange={handleManualProductChange} />
                </Grid>
                <Grid item xs={6} sm={4}>
                  <TextField fullWidth label="Birim *" name="unit" value={manualProduct.unit} onChange={handleManualProductChange} />
                </Grid>
                <Grid item xs={12} sm={4}>
                   <Button fullWidth variant="contained" startIcon={<AddIcon />} onClick={handleAddManualProduct} sx={{ height: '100%' }}>
                    Ürünü Ekle
                  </Button>
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField fullWidth label="Marka" name="brand" value={manualProduct.brand} onChange={handleManualProductChange} />
                </Grid>
                <Grid item xs={12} sm={6}>
                  <TextField fullWidth label="Model" name="model" value={manualProduct.model} onChange={handleManualProductChange} />
                </Grid>
                <Grid item xs={12}>
                  <TextField fullWidth multiline rows={2} label="Açıklama" name="description" value={manualProduct.description} onChange={handleManualProductChange} />
                </Grid>
              </Grid>
            </TabPanel>
            
            <CardContent>
              {isProcessing && (
                <Paper sx={{ p: 2, mb: 3 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                    <CircularProgress size={20} />
                    <Box sx={{ flexGrow: 1 }}>
                      <Typography variant="body2">İşlem devam ediyor...</Typography>
                      <LinearProgress variant="determinate" value={processingProgress} sx={{ mt: 1 }} />
                    </Box>
                  </Box>
                </Paper>
              )}

              {extractedProducts.length > 0 && (
                <Card sx={{ mb: 3 }}>
                  <CardHeader 
                    title={`Çıkarılan Ürünler (${extractedProducts.length})`}
                    action={
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                        <FormControlLabel
                          control={
                            <Checkbox
                              checked={isAllSelected}
                              indeterminate={isSomeSelected}
                              onChange={handleSelectAll}
                            />
                          }
                          label="Tümünü Seç"
                        />
                        <Button
                          variant="contained"
                          size="small"
                          startIcon={<PlaylistAddCheckIcon />}
                          onClick={addSelectedProducts}
                          disabled={numSelected === 0}
                        >
                          Seçilenleri Ekle
                        </Button>
                      </Box>
                    }
                  />
                  <CardContent sx={{ maxHeight: 400, overflow: 'auto' }}>
                    <Grid container spacing={2}>
                      {extractedProducts.map((product) => (
                        <Grid item xs={12} sm={6} key={product.id}>
                          <Paper 
                            sx={{ p: 2, cursor: 'pointer', border: product.selected ? '2px solid #1976d2' : '1px solid #e0e0e0', '&:hover': { boxShadow: 2 }, position: 'relative' }}
                            onClick={() => toggleProductSelection(product.id)}
                          >
                            <Chip label={product.source?.replace('ai-', '').replace('pattern-', 'Pattern')} size="small" sx={{ position: 'absolute', top: 8, right: 8, bgcolor: product.source?.includes('ai') ? '#e3f2fd' : '#f3e5f5' }} />
                            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                              <Box sx={{ flex: 1 }}>
                                <Typography variant="subtitle2" fontWeight="bold" noWrap>{product.name}</Typography>
                                <Typography variant="body2" color="text.secondary">{product.quantity} {product.unit}</Typography>
                                {product.estimatedPrice > 0 && (<Typography variant="body2" color="text.secondary">~{product.estimatedPrice} {product.currency}</Typography>)}
                              </Box>
                              <Box>
                                {product.selected && (<CheckIcon color="primary" sx={{ mr: 1 }} />)}
                                <IconButton size="small" onClick={(e) => { e.stopPropagation(); handleEditProduct(product, false); }}><EditIcon /></IconButton>
                              </Box>
                            </Box>
                          </Paper>
                        </Grid>
                      ))}
                    </Grid>
                  </CardContent>
                </Card>
              )}

              {selectedProducts.length > 0 && (
                <Card>
                  <CardHeader title={`Talebe Eklenecek Ürünler (${selectedProducts.length})`} />
                  <CardContent>
                    <TableContainer component={Paper}>
                      <Table size="small">
                        <TableHead>
                          <TableRow>
                            <TableCell>Ürün Adı</TableCell>
                            <TableCell>Miktar</TableCell>
                            <TableCell>Fiyat</TableCell>
                            <TableCell>İşlemler</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {selectedProducts.map((product) => (
                            <TableRow key={product.id}>
                              <TableCell>
                                <Typography variant="body2" fontWeight="bold">{product.name}</Typography>
                                <Typography variant="caption" color="text.secondary">{product.brand} {product.model}</Typography>
                              </TableCell>
                              <TableCell>{product.quantity} {product.unit}</TableCell>
                              <TableCell>{product.estimatedPrice > 0 ? `${product.estimatedPrice} ${product.currency}` : '-'}</TableCell>
                              <TableCell>
                                <IconButton size="small" onClick={() => handleEditProduct(product, true)}><EditIcon /></IconButton>
                                <IconButton size="small" onClick={() => handleDeleteProduct(product.id)}><DeleteIcon /></IconButton>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </CardContent>
                </Card>
              )}
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={5}>
          <Card>
            <CardHeader title="Talep Bilgileri" />
            <CardContent>
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <TextField fullWidth label="Talep Başlığı *" value={requestData.title} onChange={(e) => setRequestData(prev => ({ ...prev, title: e.target.value }))} required />
                </Grid>
                <Grid item xs={12}>
                  <TextField fullWidth multiline rows={4} label="Açıklama" value={requestData.description} onChange={(e) => setRequestData(prev => ({ ...prev, description: e.target.value }))} />
                </Grid>
                <Grid item xs={6}>
                  <FormControl fullWidth>
                    <InputLabel>Öncelik</InputLabel>
                    <Select value={requestData.priority} label="Öncelik" onChange={(e) => setRequestData(prev => ({ ...prev, priority: e.target.value }))}>
                      <MenuItem value="low">Düşük</MenuItem>
                      <MenuItem value="medium">Orta</MenuItem>
                      <MenuItem value="high">Yüksek</MenuItem>
                      <MenuItem value="urgent">Acil</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                <Grid item xs={6}>
                  <TextField fullWidth label="Departman" value={requestData.department} onChange={(e) => setRequestData(prev => ({ ...prev, department: e.target.value }))} />
                </Grid>
                <Grid item xs={12}><Divider sx={{ my: 1 }} /><Typography variant="subtitle2" gutterBottom>Talep Eden Bilgileri</Typography></Grid>
                <Grid item xs={6}><TextField fullWidth label="Ad Soyad" value={requestData.requesterName} onChange={(e) => setRequestData(prev => ({ ...prev, requesterName: e.target.value }))} /></Grid>
                <Grid item xs={6}>
                    <FormControl fullWidth>
                        <InputLabel>Şirket</InputLabel>
                        <Select
                            value={requestData.companyName}
                            label="Şirket"
                            onChange={(e) => setRequestData(prev => ({ ...prev, companyName: e.target.value }))}
                        >
                            {/* Artık 'companies' her zaman bir dizi olduğu için .map() hatasız çalışacak */}
                            {companies.map((company) => (
                                <MenuItem key={company.id} value={company.name}>
                                    {company.name}
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={6}><TextField fullWidth label="E-posta" type="email" value={requestData.requesterEmail} onChange={(e) => setRequestData(prev => ({ ...prev, requesterEmail: e.target.value }))} /></Grid>
                <Grid item xs={6}><TextField fullWidth label="Telefon" value={requestData.requesterPhone} onChange={(e) => setRequestData(prev => ({ ...prev, requesterPhone: e.target.value }))} /></Grid>
                <Grid item xs={12}>
                  <Box sx={{ display: 'flex', justifyContent: 'center', mt: 2 }}>
                    <Button
                      variant="contained"
                      size="large"
                      startIcon={<SendIcon />}
                      onClick={handleSubmitRequest}
                      disabled={isProcessing || !requestData.title.trim() || selectedProducts.length === 0}
                      sx={{ minWidth: 200 }}
                    >
                      {isProcessing ? (<><CircularProgress size={20} sx={{ mr: 1 }} /> Gönderiliyor...</>) : ('Talebi Gönder')}
                    </Button>
                  </Box>
                </Grid>
              </Grid>
            </CardContent>
          </Card>
        </Grid>
      </Grid>

      <Dialog open={editDialog.open} onClose={() => setEditDialog({ open: false, product: null, index: -1, isForSelected: false })} maxWidth="sm" fullWidth>
        <DialogTitle>Ürün Düzenle</DialogTitle>
        <DialogContent>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={12}><TextField fullWidth label="Ürün Adı *" value={editDialog.product?.name || ''} onChange={(e) => setEditDialog(prev => ({ ...prev, product: { ...prev.product, name: e.target.value } }))} required /></Grid>
            <Grid item xs={6}><TextField fullWidth label="Marka" value={editDialog.product?.brand || ''} onChange={(e) => setEditDialog(prev => ({ ...prev, product: { ...prev.product, brand: e.target.value } }))} /></Grid>
            <Grid item xs={6}><TextField fullWidth label="Model" value={editDialog.product?.model || ''} onChange={(e) => setEditDialog(prev => ({ ...prev, product: { ...prev.product, model: e.target.value } }))} /></Grid>
            <Grid item xs={6}><TextField fullWidth label="Miktar *" type="number" value={editDialog.product?.quantity || ''} onChange={(e) => setEditDialog(prev => ({ ...prev, product: { ...prev.product, quantity: parseInt(e.target.value) || 0 } }))} required /></Grid>
            <Grid item xs={6}><TextField fullWidth label="Birim *" value={editDialog.product?.unit || ''} onChange={(e) => setEditDialog(prev => ({ ...prev, product: { ...prev.product, unit: e.target.value } }))} required /></Grid>
            <Grid item xs={6}><TextField fullWidth label="Tahmini Fiyat" type="number" value={editDialog.product?.estimatedPrice || ''} onChange={(e) => setEditDialog(prev => ({ ...prev, product: { ...prev.product, estimatedPrice: parseFloat(e.target.value) || 0 } }))} /></Grid>
            <Grid item xs={6}><TextField fullWidth label="Para Birimi" value={editDialog.product?.currency || 'TL'} onChange={(e) => setEditDialog(prev => ({ ...prev, product: { ...prev.product, currency: e.target.value } }))} /></Grid>
            <Grid item xs={12}><TextField fullWidth multiline rows={3} label="Açıklama" value={editDialog.product?.description || ''} onChange={(e) => setEditDialog(prev => ({ ...prev, product: { ...prev.product, description: e.target.value } }))} /></Grid>
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setEditDialog({ open: false, product: null, index: -1, isForSelected: false })}>İptal</Button>
          <Button onClick={handleUpdateProduct} variant="contained">Güncelle</Button>
        </DialogActions>
      </Dialog>
      
      <Snackbar open={notification.open} autoHideDuration={6000} onClose={() => setNotification({ ...notification, open: false })} anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}>
        <Alert onClose={() => setNotification({ ...notification, open: false })} severity={notification.severity} sx={{ width: '100%' }}>{notification.message}</Alert>
      </Snackbar>
    </Box>
  );
};

}
export default UnifiedRequestSystem;
