import React, { useState, useEffect, useRef } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Button,
  Grid,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Chip,
  Avatar,
  Snackbar,
  Alert,
  Tabs,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  IconButton,
  Divider,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  CardActions,
  Drawer,
  OutlinedInput
} from '@mui/material';
import {
  Add as AddIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Business as BusinessIcon,
  AccountBalance as BankIcon,
  CloudUpload as UploadIcon,
  PhotoCamera as CameraIcon,
  Visibility as VisibilityIcon,
  Save as SaveIcon,
  Cancel as CancelIcon,
  Article as DocxIcon,
  PictureAsPdf as PdfIcon,
  AutoAwesome as AiIcon,
  Email as EmailIcon,
  Phone as PhoneIcon,
  RemoveCircleOutline as RemoveIcon
} from '@mui/icons-material';

// Gerekli kütüphaneler
import { saveAs } from 'file-saver';
import html2pdf from 'html2pdf.js';

// --- VERİ TANIMLAMALARI ---

// 1. Ana 9 Firma (Başlangıç Listesi)
const mainCompaniesArray = [
    { id: 1, name: 'BN İNOVASYON YAPI DIŞ TİCARET ANONİM ŞİRKETİ', emails: ['info@bninovasyon.com'], phones: ['+905375564665'], address: 'KOZA MAH. ATATÜRK BUL. DUMANKAYA MODERN VADİ SİTESİ A4 BLOK NO: 20İ İÇ KAPI NO: 3 ESENYURT / İSTANBUL', taxNumber: '1781779298', taxOffice: 'ESENYURT VERGİ DAİRESİ', mersisNumber: '0178177929800001', tradeRegistryNumber: '1025929', companyType: 'TEK PAY SAHİPLİ ANONİM ŞİRKET', totalCapital: '1.000.000,00 TL', foundedDate: '26-06-2024', city: 'İSTANBUL', electronicNotificationAddress: '25828-12810-70206', status: 'active', logoUrl: null },
    { id: 2, name: 'ALÜMTAŞ METAL LİMİTED ŞİRKETİ', emails: ['info@alumtas.com'], phones: [], address: 'BAHÇEŞEHİR 2. KISIM MAH. 50. YIL CAD. AYRUPARK SİTESİ BD4 BLOK NO: 8N İÇ KAPI NO: 6 BAŞAKŞEHİR / İSTANBUL', taxNumber: '0882007968', taxOffice: 'BAŞAKŞEHİR VERGİ DAİRESİ', mersisNumber: '0088200796800001', tradeRegistryNumber: '1069282', companyType: 'TEK ORTAKLI LİMİTED ŞİRKET', totalCapital: '30.000.000,00 TL', foundedDate: '12-02-2025', city: 'İSTANBUL', electronicNotificationAddress: '25707-13913-02999', status: 'active', logoUrl: null },
    { id: 3, name: 'GLOBAL TREND YAPI TİCARET ANONİM ŞİRKETİ', emails: ['info@globaltrend.com', 'iletisim@globaltrend.com'], phones: ['+902121234567'], address: 'BAHÇEŞEHİR 2. KISIM MAH. AYÇİÇEĞİ SK. ARTI YAPI KOP. SİTESİ STAR PLAZA NO: 20 İÇ KAPI NO: 19 BAŞAKŞEHİR / İSTANBUL', taxNumber: '3961668089', taxOffice: 'BAŞAKŞEHİR VERGİ DAİRESİ', mersisNumber: '0396166808900001', tradeRegistryNumber: '1033280', companyType: 'TEK PAY SAHİPLİ ANONİM ŞİRKET', totalCapital: '1.000.000,00 TL', foundedDate: '14-08-2024', city: 'İSTANBUL', electronicNotificationAddress: '25838-30601-91309', status: 'active', logoUrl: null },
    { id: 4, name: 'ÖRNEK LOJİSTİK A.Ş.', emails: ['info@orneklojistik.com'], phones: ['+903129876543'], address: 'LOJİSTİK MAH. GÜMRÜK SK. NO:1 ANKARA', taxNumber: '1234567890', taxOffice: 'ANKARA VERGİ DAİRESİ', mersisNumber: '012345678900001', tradeRegistryNumber: '987654', companyType: 'ANONİM ŞİRKET', totalCapital: '500.000,00 TL', foundedDate: '01-01-2020', city: 'ANKARA', electronicNotificationAddress: '12345-67890-12345', status: 'active', logoUrl: null },
    { id: 5, name: 'YENİLİKÇİ TEKNOLOJİ LTD. ŞTİ.', emails: ['info@yenilikcitek.com'], phones: ['+902321112233', '+905445556677'], address: 'BİLİM MAH. İNOVASYON CAD. NO:5 İZMİR', taxNumber: '0987654321', taxOffice: 'İZMİR VERGİ DAİRESİ', mersisNumber: '098765432100001', tradeRegistryNumber: '543210', companyType: 'LİMİTED ŞİRKET', totalCapital: '100.000,00 TL', foundedDate: '01-06-2022', city: 'İZMİR', electronicNotificationAddress: '54321-09876-54321', status: 'active', logoUrl: null },
    { id: 6, name: 'ÇELİK YAPI A.Ş.', emails: ['info@celikyapi.com'], phones: ['+902167890123'], address: 'İnşaat Sokak No:10, Üsküdar/İstanbul', taxNumber: '4567890123', taxOffice: 'ÜSKÜDAR VD', mersisNumber: '045678901230001', tradeRegistryNumber: '112233', companyType: 'Anonim Şirket', totalCapital: '2.500.000,00 TL', foundedDate: '10-03-2018', city: 'İSTANBUL', electronicNotificationAddress: 'celik_yapi@etebligat.hs03.kep.tr', status: 'active', logoUrl: null },
    { id: 7, name: 'YEMEK DÜNYASI GIDA LTD. ŞTİ.', emails: ['siparis@yemekdunyasi.com', 'muhasebe@yemekdunyasi.com'], phones: ['+902123456789'], address: 'Gıda Cad. Lezzet Sk. No:5, Fatih/İstanbul', taxNumber: '9876543210', taxOffice: 'FATİH VD', mersisNumber: '098765432100001', tradeRegistryNumber: '998877', companyType: 'Limited Şirket', totalCapital: '500.000,00 TL', foundedDate: '05-07-2019', city: 'İSTANBUL', electronicNotificationAddress: 'yemekdunyasi@etebligat.hs03.kep.tr', status: 'active', logoUrl: null },
    { id: 8, name: 'MODERN TEKSTİL SAN. A.Ş.', emails: ['info@moderntekstil.com'], phones: ['+902241234567'], address: 'Tekstil Osb. Cad. No:15, Bursa', taxNumber: '1122334455', taxOffice: 'BURSA VD', mersisNumber: '011223344550001', tradeRegistryNumber: '665544', companyType: 'Anonim Şirket', totalCapital: '10.000.000,00 TL', foundedDate: '20-11-2015', city: 'BURSA', electronicNotificationAddress: 'moderntekstil@etebligat.hs03.kep.tr', status: 'active', logoUrl: null },
    { id: 9, name: 'EGE TARIM ÜRÜNLERİ A.Ş.', emails: ['satis@egetarim.com'], phones: ['+902329876543'], address: 'Tarım Sokak No:20, İzmir', taxNumber: '6789012345', taxOffice: 'İZMİR SEFERİHİSAR VD', mersisNumber: '067890123450001', tradeRegistryNumber: '332211', companyType: 'Anonim Şirket', totalCapital: '3.000.000,00 TL', foundedDate: '01-04-2017', city: 'İZMİR', electronicNotificationAddress: 'egetarim@etebligat.hs03.kep.tr', status: 'active', logoUrl: null }
];

// 2. Müşteri ve Tedarikçiler (Başlangıç Listesi)
const initialContacts = [
    { id: 10, name: 'Inter Asia Commerce LLC', emails: [], phones: [], address: 'Kyrgyz Republic, Bishkek w/m Archa-Beshik, st. Jayyl baatyr 266 TIN: 00410202110140 Bank: CJSC «Bank of Asia» KR, Bishkek Corr ./s: 30111810000000001296 BIC: ASCJKG22', taxNumber: '2222222222', taxOffice: '', city: 'Bishkek', status: 'active', type: [] },
    { id: 11, name: 'TD ATLANT-ENGINEERING LLC', emails: ['Info@td-atlant.pro'], phones: [], address: '117218, MOSCOW, VN.TER.G. ACADEMIC MUNICIPAL DISTRICT, KRZHIZHANOVSKY STR., 20/30, Room 1 INN/KPP 6318012249 / 772701001 OGRN 1166313067689 RUSYA FEDERASYONU', taxNumber: '2222222222', taxOffice: '', city: 'MOSKOVA', status: 'active', type: [] },
    { id: 12, name: 'LLC DEVPAN', emails: [], phones: [], address: '125171, MOSCOW, VN.TER.G. MUNICIPAL DISTRICT VOYKOVSKY, SH. LENINGRADSKOYE, 16A BUILDING 3 INN/KPP 9728110750 / 774301001 OGRN 1237700739748', taxNumber: '2222222222', taxOffice: '', city: 'MOSKOVA', status: 'active', type: [] },
    { id: 13, name: 'LLC İNTER', emails: [], phones: ['+7 968 727 70 65'], address: '143002, MOSCOW REGION, G.O. ODINCOVSKIY, G. ODINTSOVO, SADOVAYA UL., 3B, OFFICE 910 TIN: 5032344194 CPP: 503201001 OGRN 1225000084110 MOSKOVA/RUSYA FEDERASYONU', taxNumber: '2222222222', taxOffice: '', city: 'MOSKOVA', status: 'active', type: [] },
    { id: 14, name: 'ATEKSİS AKILLI TEKNOLOJİ SİS.VE TİC.LTD.ŞTİ.', emails: ['info@ateksis.com'], phones: [], address: 'ŞERİFALİ M.BAYRAKTAR BL.İBRAHİM HAKKI S. 34 ÜMRANİYE İSTANBUL 34775 TÜRKİYE', taxNumber: '0990295589', taxOffice: '', city: 'İSTANBUL', status: 'active', type: [] },
    { id: 15, name: 'AG (OOO "AG-LOGISTIC" LLC)', emails: [], phones: [], address: '117246, Moscow, ext. ter. Cheryomushki Municipal District, Scientific Passage, 17, Prem. 4/9 TIN/CPP 9728100494 / 772801001 OGRN 1237700467652', taxNumber: '2222222222', taxOffice: '', city: 'Moscow', status: 'active', type: [] },
];

// --- YARDIMCI FONKSİYONLAR ---

const parseRussianTaxInfo = (address) => {
    if (!address) return { tin_inn: '', cpp_kpp: '', ogrn: '' };
    const combinedMatch = address.match(/(?:INN\/KPP|TIN\/CPP|INN\/CPP)\s*([\d\s\/]+)/i);
    const tinInnMatch = address.match(/(?:TIN|INN):\s*(\d+)/i);
    const cppKppMatch = address.match(/(?:CPP|KPP):\s*(\d+)/i);
    const ogrnMatch = address.match(/OGRN\s*(\d+)/i);
    const taxNumberMatch = address.match(/TAX NUMBER:\s*(\d+)/i);
    let tin_inn = '';
    let cpp_kpp = '';
    if (combinedMatch && combinedMatch[1]) {
        const parts = combinedMatch[1].split('/').map(p => p.trim());
        tin_inn = parts[0] || '';
        cpp_kpp = parts[1] || '';
    } else {
        if (tinInnMatch && tinInnMatch[1]) tin_inn = tinInnMatch[1];
        if (cppKppMatch && cppKppMatch[1]) cpp_kpp = cppKppMatch[1];
    }
    if (!tin_inn && taxNumberMatch && taxNumberMatch[1]) tin_inn = taxNumberMatch[1];
    const ogrn = ogrnMatch ? ogrnMatch[1] : '';
    return { tin_inn, cpp_kpp, ogrn };
};

function TabPanel(props) {
  const { children, value, index, ...other } = props;
  return (
    <div role="tabpanel" hidden={value !== index} id={`simple-tabpanel-${index}`} aria-labelledby={`simple-tab-${index}`} {...other}>
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
}

const CompanyManagement = () => {
  // --- STATE TANIMLAMALARI ---
  const [mainCompanies, setMainCompanies] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [selectedEntity, setSelectedEntity] = useState(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [editingEntityType, setEditingEntityType] = useState(null); // 'main' or 'contact'
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [drawerTab, setDrawerTab] = useState(0);
  const [mainTab, setMainTab] = useState(0);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const fileInputRef = useRef(null);
  const pdfRef = useRef();
  
  const [entityForm, setEntityForm] = useState({ 
    id: null, name: '', emails: [''], phones: [''], address: '', taxNumber: '', taxOffice: '', 
    mersisNumber: '', tradeRegistryNumber: '', companyType: '', totalCapital: '', 
    foundedDate: '', city: '', electronicNotificationAddress: '', status: 'active', logoUrl: null, type: [],
    tin_inn: '', cpp_kpp: '', ogrn: ''
  });

  const [bankAccounts, setBankAccounts] = useState([]);
  const [openBankDialog, setOpenBankDialog] = useState(false);
  const [bankForm, setBankForm] = useState({ id: null, companyId: null, bankName: '', currency: 'TL', iban: '', accountType: 'Vadesiz Hesap' });
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiGeneratedText, setAiGeneratedText] = useState('');
  const [isGeneratingDoc, setIsGeneratingDoc] = useState(false);

  const turkishBanks = [ 'Türkiye İş Bankası A.Ş.', 'Türkiye Garanti Bankası A.Ş.', 'Yapı ve Kredi Bankası A.Ş.', 'Akbank T.A.Ş.', 'Türkiye Halk Bankası A.Ş.', 'Türkiye Ziraat Bankası A.Ş.', 'Türkiye Vakıflar Bankası T.A.O.', 'Denizbank A.Ş.', 'QNB Finansbank A.Ş.', 'Albaraka Türk Katılım Bankası A.Ş.', 'Kuveyt Türk Katılım Bankası A.Ş.', 'Türkiye Finans Katılım Bankası A.Ş.', 'Vakıf Katılım Bankası A.Ş.', 'Ziraat Katılım Bankası A.Ş.', 'Emlak Katılım Bankası A.Ş.' ];
  const currencies = ['TL', 'USD', 'EUR', 'GBP', 'RUB'];

  // --- useEffect ---
  useEffect(() => {
    // Ana Firmaları Yükle
    let storedMainCompanies = JSON.parse(localStorage.getItem('mainCompanies'));
    if (!storedMainCompanies || storedMainCompanies.length === 0) {
      localStorage.setItem('mainCompanies', JSON.stringify(mainCompaniesArray));
      storedMainCompanies = mainCompaniesArray;
    }
    setMainCompanies(storedMainCompanies);

    // Kişileri (Müşteri/Tedarikçi) Yükle
    let storedContacts = JSON.parse(localStorage.getItem('contacts'));
    if (!storedContacts || storedContacts.length === 0) {
      const parsedInitialContacts = initialContacts.map(contact => ({ ...contact, ...parseRussianTaxInfo(contact.address) }));
      localStorage.setItem('contacts', JSON.stringify(parsedInitialContacts));
      storedContacts = parsedInitialContacts;
    }
    setContacts(storedContacts.map(c => ({...c, type: c.type || []})));
    
    // Banka Hesaplarını Yükle
    const storedBankAccounts = JSON.parse(localStorage.getItem('bankAccounts') || '[]');
    setBankAccounts(storedBankAccounts);
  }, []);

  // --- FONKSİYONLAR ---
  const showSnackbar = (message, severity) => setSnackbar({ open: true, message, severity });
  
  const handleOpenDialog = (entity, type) => {
    setEditingEntityType(type);
    setEntityForm({ 
      ...entity, 
      type: entity.type || [],
      emails: entity.emails && entity.emails.length > 0 ? entity.emails : [''],
      phones: entity.phones && entity.phones.length > 0 ? entity.phones : [''],
    });
    setOpenDialog(true);
  };

  const handleAddNewContact = () => {
    setEditingEntityType('contact');
    resetEntityForm();
    setOpenDialog(true);
  };
  
  const handleCloseDialog = () => setOpenDialog(false);

  const handleSave = () => {
    if (!entityForm.name) {
      showSnackbar('Firma adı boş bırakılamaz.', 'error');
      return;
    }

    const cleanedEmails = entityForm.emails.filter(email => email && email.trim() !== '');
    const cleanedPhones = entityForm.phones.filter(phone => phone && phone.trim() !== '');

    const entityToSave = {
        ...entityForm,
        emails: cleanedEmails.length > 0 ? cleanedEmails : [''],
        phones: cleanedPhones.length > 0 ? cleanedPhones : ['']
    };

    if (editingEntityType === 'main') {
        const updatedCompanies = mainCompanies.map(c => c.id === entityToSave.id ? entityToSave : c);
        setMainCompanies(updatedCompanies);
        localStorage.setItem('mainCompanies', JSON.stringify(updatedCompanies));
        showSnackbar('Ana firma güncellendi.', 'success');
    } else {
        let updatedContacts;
        if (entityForm.id) { // Düzenleme
            updatedContacts = contacts.map(c => c.id === entityToSave.id ? entityToSave : c);
        } else { // Yeni ekleme
            const newContact = { ...entityToSave, id: Date.now() };
            updatedContacts = [...contacts, newContact];
        }
        setContacts(updatedContacts);
        localStorage.setItem('contacts', JSON.stringify(updatedContacts));
        showSnackbar(entityForm.id ? 'Kayıt güncellendi.' : 'Yeni kayıt eklendi.', 'success');
    }
    
    handleCloseDialog();
  };

  const handleDeleteContact = (contactId) => {
    const updatedContacts = contacts.filter(c => c.id !== contactId);
    setContacts(updatedContacts);
    localStorage.setItem('contacts', JSON.stringify(updatedContacts));
    showSnackbar('Kayıt silindi.', 'warning');
  };
  
  const handleLogoUpload = (event) => {
      const file = event.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (e) => {
          setEntityForm({...entityForm, logoUrl: e.target.result});
          showSnackbar('Logo yüklendi, kaydetmeyi unutmayın.', 'info');
      };
      reader.readAsDataURL(file);
  };
  
  const handleOpenDetailsDrawer = (entity) => {
    setSelectedEntity(entity);
    setDrawerTab(0);
    setDrawerOpen(true);
  };

  const resetEntityForm = () => {
    setEntityForm({ 
      id: null, name: '', emails: [''], phones: [''], address: '', taxNumber: '', taxOffice: '', 
      mersisNumber: '', tradeRegistryNumber: '', companyType: '', totalCapital: '', 
      foundedDate: '', city: '', electronicNotificationAddress: '', status: 'active', logoUrl: null, type: [],
      tin_inn: '', cpp_kpp: '', ogrn: ''
    });
  };

  // --- Form Alanı Yönetimi ---
  const handleFormChange = (e) => setEntityForm({ ...entityForm, [e.target.name]: e.target.value });
  const handleContactTypeChange = (event) => {
    const { target: { value } } = event;
    setEntityForm({ ...entityForm, type: typeof value === 'string' ? value.split(',') : value });
  };
  const handleEmailChange = (index, value) => {
    const newEmails = [...entityForm.emails];
    newEmails[index] = value;
    setEntityForm({ ...entityForm, emails: newEmails });
  };
  const handleAddEmail = () => setEntityForm({ ...entityForm, emails: [...entityForm.emails, ''] });
  const handleRemoveEmail = (index) => {
    const newEmails = entityForm.emails.filter((_, i) => i !== index);
    setEntityForm({ ...entityForm, emails: newEmails.length > 0 ? newEmails : [''] });
  };
  const handlePhoneChange = (index, value) => {
    const newPhones = [...entityForm.phones];
    newPhones[index] = value;
    setEntityForm({ ...entityForm, phones: newPhones });
  };
  const handleAddPhone = () => setEntityForm({ ...entityForm, phones: [...entityForm.phones, ''] });
  const handleRemovePhone = (index) => {
    const newPhones = entityForm.phones.filter((_, i) => i !== index);
    setEntityForm({ ...entityForm, phones: newPhones.length > 0 ? newPhones : [''] });
  };

  // --- Ortak Fonksiyonlar (Banka, PDF, AI) ---
  const handleSaveBankAccount = () => {
    if (!bankForm.bankName || !bankForm.iban) {
        showSnackbar('Banka adı ve IBAN zorunludur.', 'error');
        return;
    }
    let updatedAccounts;
    const accountToSave = { ...bankForm, companyId: selectedEntity.id };
    if (bankForm.id) {
        updatedAccounts = bankAccounts.map(acc => acc.id === bankForm.id ? accountToSave : acc);
    } else {
        updatedAccounts = [...bankAccounts, { ...accountToSave, id: Date.now() }];
    }
    setBankAccounts(updatedAccounts);
    localStorage.setItem('bankAccounts', JSON.stringify(updatedAccounts));
    setOpenBankDialog(false);
    showSnackbar('Banka hesabı kaydedildi.', 'success');
  };

  const handleDeleteBankAccount = (accountId) => {
    const updatedAccounts = bankAccounts.filter(acc => acc.id !== accountId);
    setBankAccounts(updatedAccounts);
    localStorage.setItem('bankAccounts', JSON.stringify(updatedAccounts));
    showSnackbar('Banka hesabı silindi.', 'warning');
  };
  
  const handleExportPdf = () => {
    const element = pdfRef.current;
    if (!element) return;
    const opt = {
      margin: 0.5,
      filename: `cari-kart-${selectedEntity.name.replace(/\s/g, '_')}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true },
      jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' }
    };
    html2pdf().set(opt).from(element).save();
  };

  const handleGenerateAiDocument = async () => { /* ... */ };

  // --- RENDER FONKSİYONLARI ---
  const renderMainCompanyCard = (company) => (
    <Grid item xs={12} md={6} lg={4} key={company.id}>
        <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <CardContent sx={{ flexGrow: 1 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                    <Avatar src={company.logoUrl} sx={{ bgcolor: 'primary.light', color: 'primary.dark', width: 56, height: 56, mr: 2 }}>
                        {!company.logoUrl && company.name.charAt(0)}
                    </Avatar>
                    <Box>
                        <Typography variant="h6" component="h2" noWrap title={company.name}>
                            {company.name.length > 35 ? `${company.name.substring(0, 35)}...` : company.name}
                        </Typography>
                        <Chip label="Ana Firma" size="small" color="primary" />
                    </Box>
                </Box>
                <Divider sx={{ my: 1.5 }} />
                <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}><strong>Şehir:</strong> {company.city}</Typography>
                <Typography variant="body2" color="text.secondary"><strong>Vergi No:</strong> {company.taxNumber}</Typography>
            </CardContent>
            <CardActions>
                <Button size="small" startIcon={<VisibilityIcon />} onClick={() => handleOpenDetailsDrawer(company)}>Detaylar</Button>
                <Button size="small" startIcon={<EditIcon />} onClick={() => handleOpenDialog(company, 'main')}>Düzenle</Button>
            </CardActions>
        </Card>
    </Grid>
  );

  const renderContactCard = (contact) => (
    <Grid item xs={12} md={6} lg={4} key={contact.id}>
        <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
        <CardContent sx={{ flexGrow: 1 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
            <Avatar src={contact.logoUrl} sx={{ bgcolor: 'secondary.light', color: 'secondary.dark', width: 56, height: 56, mr: 2 }}>
                {!contact.logoUrl && contact.name.charAt(0)}
            </Avatar>
            <Box>
                <Typography variant="h6" component="h2" noWrap title={contact.name}>
                {contact.name.length > 35 ? `${contact.name.substring(0, 35)}...` : contact.name}
                </Typography>
                <Box sx={{ mt: 1 }}>
                    {contact.type.includes('customer') && <Chip label="Müşteri" size="small" color="info" sx={{ mr: 0.5 }} />}
                    {contact.type.includes('supplier') && <Chip label="Tedarikçi" size="small" color="warning" />}
                </Box>
            </Box>
            </Box>
            <Divider sx={{ my: 1.5 }} />
            <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}><strong>Şehir:</strong> {contact.city || 'Belirtilmemiş'}</Typography>
            {contact.tin_inn && <Typography variant="body2" color="text.secondary" sx={{fontSize: '0.8rem'}}><strong>TIN/INN:</strong> {contact.tin_inn}</Typography>}
        </CardContent>
        <CardActions>
            <Button size="small" startIcon={<VisibilityIcon />} onClick={() => handleOpenDetailsDrawer(contact)}>Detaylar</Button>
            <Button size="small" startIcon={<EditIcon />} onClick={() => handleOpenDialog(contact, 'contact')}>Düzenle</Button>
            <IconButton size="small" color="error" onClick={() => handleDeleteContact(contact.id)}><DeleteIcon /></IconButton>
        </CardActions>
        </Card>
    </Grid>
  );

  return (
    <Box sx={{ p: 3, bgcolor: 'grey.50', minHeight: 'calc(100vh - 64px)' }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
            <Typography variant="h4" component="h1">Firma ve Cari Yönetimi</Typography>
            <Button variant="contained" startIcon={<AddIcon />} onClick={handleAddNewContact}>
                Yeni Cari Ekle
            </Button>
        </Box>
        
        <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
            <Tabs value={mainTab} onChange={(e, newValue) => setMainTab(newValue)} aria-label="yönetim sekmeleri">
                <Tab label={`Ana Firmalar (${mainCompanies.length})`} />
                <Tab label={`Müşteri & Tedarikçiler (${contacts.length})`} />
            </Tabs>
        </Box>

        {/* --- SEKMELER --- */}
        <TabPanel value={mainTab} index={0}>
            <Grid container spacing={3}>
                {mainCompanies.map(renderMainCompanyCard)}
            </Grid>
        </TabPanel>

        <TabPanel value={mainTab} index={1}>
            <Typography variant="h5" sx={{ mb: 2, color: 'info.dark' }}>Müşteriler</Typography>
            <Grid container spacing={3}>
                {contacts.filter(c => c.type.includes('customer')).map(renderContactCard)}
            </Grid>
            <Divider sx={{ my: 4 }}><Chip label="Tedarikçiler" /></Divider>
            <Typography variant="h5" sx={{ mb: 2, color: 'warning.dark' }}>Tedarikçiler</Typography>
            <Grid container spacing={3}>
                {contacts.filter(c => c.type.includes('supplier')).map(renderContactCard)}
            </Grid>
            <Divider sx={{ my: 4 }}><Chip label="Diğer" /></Divider>
            <Typography variant="h5" sx={{ mb: 2, color: 'text.secondary' }}>Kategorize Edilmemiş</Typography>
            <Grid container spacing={3}>
                {contacts.filter(c => !c.type || c.type.length === 0).map(renderContactCard)}
            </Grid>
        </TabPanel>

      {/* --- DİYALOG (FORM) --- */}
      <Dialog open={openDialog} onClose={handleCloseDialog} fullWidth maxWidth="md">
        <DialogTitle>{entityForm.id ? 'Kaydı Düzenle' : 'Yeni Cari Kayıt Ekle'}</DialogTitle>
        <DialogContent>
            <Grid container spacing={2} sx={{mt: 1}}>
                <Grid item xs={12} md={3} sx={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1}}>
                     <Avatar src={entityForm.logoUrl} sx={{ width: 120, height: 120, mb: 1, fontSize: '3rem' }}>
                        {!entityForm.logoUrl && entityForm.name.charAt(0)}
                     </Avatar>
                     <Button component="label" variant="outlined" startIcon={<CameraIcon />}>
                         Logo Yükle
                         <input type="file" hidden accept="image/*" onChange={handleLogoUpload} />
                     </Button>
                </Grid>
                <Grid item xs={12} md={9}>
                    <TextField fullWidth name="name" label="Firma Adı *" value={entityForm.name} onChange={handleFormChange} sx={{mb: 2}} />
                    {entityForm.emails.map((email, index) => (
                        <Box key={index} sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                            <TextField fullWidth label={`E-posta ${index + 1}`} value={email} onChange={(e) => handleEmailChange(index, e.target.value)} sx={{ mr: 1 }} />
                            {entityForm.emails.length > 1 && <IconButton onClick={() => handleRemoveEmail(index)} color="error"><RemoveIcon /></IconButton>}
                        </Box>
                    ))}
                    <Button variant="outlined" startIcon={<AddIcon />} onClick={handleAddEmail} size="small">E-posta Ekle</Button>
                </Grid>
                <Grid item xs={12}><TextField fullWidth name="address" label="Adres" multiline rows={2} value={entityForm.address} onChange={handleFormChange} /></Grid>
                <Grid item xs={12}><Divider sx={{my:1}}><Chip label="Resmi Bilgiler" /></Divider></Grid>
                <Grid item xs={12} sm={6} md={4}><TextField fullWidth name="city" label="Şehir" value={entityForm.city} onChange={handleFormChange} /></Grid>
                <Grid item xs={12} sm={6} md={4}><TextField fullWidth name="taxOffice" label="Vergi Dairesi" value={entityForm.taxOffice} onChange={handleFormChange} /></Grid>
                <Grid item xs={12} sm={6} md={4}><TextField fullWidth name="taxNumber" label="Vergi Numarası" value={entityForm.taxNumber} onChange={handleFormChange} /></Grid>
                <Grid item xs={12} sm={6} md={4}><TextField fullWidth name="tin_inn" label="TIN / INN" value={entityForm.tin_inn} onChange={handleFormChange} /></Grid>
                <Grid item xs={12} sm={6} md={4}><TextField fullWidth name="cpp_kpp" label="CPP / KPP" value={entityForm.cpp_kpp} onChange={handleFormChange} /></Grid>
                <Grid item xs={12} sm={6} md={4}><TextField fullWidth name="ogrn" label="OGRN" value={entityForm.ogrn} onChange={handleFormChange} /></Grid>
                {editingEntityType === 'contact' && (
                    <Grid item xs={12}>
                        <FormControl fullWidth sx={{ mt: 2 }}>
                            <InputLabel id="contact-type-label">Cari Tipi</InputLabel>
                            <Select labelId="contact-type-label" multiple value={entityForm.type} onChange={handleContactTypeChange} input={<OutlinedInput label="Cari Tipi" />}
                                renderValue={(selected) => (
                                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                                        {selected.map((value) => (<Chip key={value} label={value === 'customer' ? 'Müşteri' : 'Tedarikçi'} />))}
                                    </Box>
                                )}>
                                <MenuItem value="customer">Müşteri</MenuItem>
                                <MenuItem value="supplier">Tedarikçi</MenuItem>
                            </Select>
                        </FormControl>
                    </Grid>
                )}
            </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>İptal</Button>
          <Button onClick={handleSave} variant="contained">Kaydet</Button>
        </DialogActions>
      </Dialog>
      
      {/* --- DETAY ÇEKMECESİ --- */}
      <Drawer anchor="right" open={drawerOpen} onClose={() => setDrawerOpen(false)}>
        <Box sx={{ width: { xs: '100%', sm: 600, md: 700 }, p: 2 }}>
            {selectedEntity && (
                <>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Typography variant="h5">Detaylar</Typography>
                    <IconButton onClick={() => setDrawerOpen(false)}><CancelIcon /></IconButton>
                </Box>
                <Divider sx={{ my: 2 }} />
                <Tabs value={drawerTab} onChange={(e, newValue) => setDrawerTab(newValue)} variant="fullWidth">
                    <Tab label="Cari Kart" />
                    <Tab label="Banka Hesapları" />
                    <Tab label="AI Belge Oluştur" />
                </Tabs>
                <TabPanel value={drawerTab} index={0}>
                    <Box ref={pdfRef} sx={{p: 3, border: '1px solid #eee', mb: 2, bgcolor: 'white', color: 'black'}}>
                        <Box sx={{display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', borderBottom: '2px solid #1976d2', pb: 2, mb: 3}}>
                            <Box>
                                <Typography variant="h4" component="h1" fontWeight="bold" color="#1976d2">{selectedEntity.name}</Typography>
                                <Typography variant="body1">{selectedEntity.companyType}</Typography>
                            </Box>
                            {selectedEntity.logoUrl && <Avatar src={selectedEntity.logoUrl} sx={{ width: 80, height: 80, ml: 2, borderRadius: '8px' }} variant="square" />}
                        </Box>
                        <Grid container spacing={2}>
                            <Grid item xs={7}>
                                <Typography variant="subtitle2" color="text.secondary">Adres</Typography>
                                <Typography variant="body2">{selectedEntity.address}</Typography>
                                <Typography variant="body2">{selectedEntity.city}</Typography>
                            </Grid>
                            <Grid item xs={5}>
                                <Typography variant="subtitle2" color="text.secondary">İletişim</Typography>
                                {selectedEntity.emails?.map(e => e && <Typography key={e} variant="body2">{e}</Typography>)}
                                {selectedEntity.phones?.map(p => p && <Typography key={p} variant="body2">{p}</Typography>)}
                            </Grid>
                            <Grid item xs={12}><Divider sx={{ my: 2 }} /></Grid>
                            <Grid item xs={6}>
                                <Typography variant="subtitle2" color="text.secondary">Vergi Dairesi / No</Typography>
                                <Typography variant="body2">{selectedEntity.taxOffice} / {selectedEntity.taxNumber}</Typography>
                            </Grid>
                             <Grid item xs={6}>
                                <Typography variant="subtitle2" color="text.secondary">Ticaret Sicil / MERSİS</Typography>
                                <Typography variant="body2">{selectedEntity.tradeRegistryNumber} / {selectedEntity.mersisNumber}</Typography>
                            </Grid>
                             {(selectedEntity.tin_inn || selectedEntity.cpp_kpp || selectedEntity.ogrn) && (
                                <>
                                <Grid item xs={4}><Typography variant="subtitle2" color="text.secondary">TIN/INN</Typography><Typography variant="body2">{selectedEntity.tin_inn}</Typography></Grid>
                                <Grid item xs={4}><Typography variant="subtitle2" color="text.secondary">CPP/KPP</Typography><Typography variant="body2">{selectedEntity.cpp_kpp}</Typography></Grid>
                                <Grid item xs={4}><Typography variant="subtitle2" color="text.secondary">OGRN</Typography><Typography variant="body2">{selectedEntity.ogrn}</Typography></Grid>
                                </>
                             )}
                        </Grid>
                    </Box>
                    <Button onClick={handleExportPdf} variant="contained" startIcon={<PdfIcon />}>Cari Kart PDF İndir</Button>
                </TabPanel>
                <TabPanel value={drawerTab} index={1}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                        <Typography variant="h6">Banka Hesapları</Typography>
                        <Button variant="contained" startIcon={<AddIcon />} onClick={() => { setOpenBankDialog(true); setBankForm({ id: null, companyId: selectedEntity.id, bankName: '', currency: 'TL', iban: '', accountType: 'Vadesiz Hesap' }); }}>
                            Yeni Hesap Ekle
                        </Button>
                    </Box>
                    <TableContainer component={Paper}>
                        <Table size="small">
                            <TableHead><TableRow><TableCell>Banka</TableCell><TableCell>Döviz</TableCell><TableCell>IBAN</TableCell><TableCell>İşlemler</TableCell></TableRow></TableHead>
                            <TableBody>
                            {bankAccounts.filter(b => b.companyId === selectedEntity.id).map((account) => (
                                <TableRow key={account.id}>
                                <TableCell>{account.bankName}</TableCell>
                                <TableCell><Chip label={account.currency} size="small" /></TableCell>
                                <TableCell>{account.iban}</TableCell>
                                <TableCell>
                                    <IconButton onClick={() => { setBankForm(account); setOpenBankDialog(true); }} size="small"><EditIcon /></IconButton>
                                    <IconButton onClick={() => handleDeleteBankAccount(account.id)} size="small" color="error"><DeleteIcon /></IconButton>
                                </TableCell>
                                </TableRow>
                            ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </TabPanel>
                <TabPanel value={drawerTab} index={2}>
                    <Typography variant="h6" sx={{ mb: 2 }}>AI Destekli Belge Oluşturucu</Typography>
                    <TextField fullWidth multiline rows={3} label="Oluşturmak istediğiniz belgeyi tanımlayın" placeholder="Örn: Tedarikçiye 15 gün geciken ödeme için ihtarname dilekçesi" value={aiPrompt} onChange={(e) => setAiPrompt(e.target.value)} />
                    <Button variant="contained" startIcon={<AiIcon />} onClick={handleGenerateAiDocument} disabled={isGeneratingDoc} sx={{ my: 2 }}>
                        {isGeneratingDoc ? 'Oluşturuluyor...' : 'AI ile Belge Oluştur'}
                    </Button>
                    {aiGeneratedText && <Paper variant="outlined" sx={{ p: 2, mt: 2, maxHeight: 300, overflow: 'auto' }}><Typography variant="body2" sx={{ whiteSpace: 'pre-wrap' }}>{aiGeneratedText}</Typography></Paper>}
                </TabPanel>
                </>
            )}
        </Box>
      </Drawer>
      
      {/* --- BANKA HESABI DİYALOĞU --- */}
      <Dialog open={openBankDialog} onClose={() => setOpenBankDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>{bankForm.id ? 'Banka Hesabı Düzenle' : 'Yeni Banka Hesabı Ekle'}</DialogTitle>
        <DialogContent>
            <Grid container spacing={2} sx={{mt: 1}}>
                <Grid item xs={12}><FormControl fullWidth><InputLabel>Banka</InputLabel><Select value={bankForm.bankName} onChange={(e) => setBankForm({ ...bankForm, bankName: e.target.value })} label="Banka">{turkishBanks.map((bank) => (<MenuItem key={bank} value={bank}>{bank}</MenuItem>))}</Select></FormControl></Grid>
                <Grid item xs={12} sm={6}><FormControl fullWidth><InputLabel>Para Birimi</InputLabel><Select value={bankForm.currency} onChange={(e) => setBankForm({ ...bankForm, currency: e.target.value })} label="Para Birimi">{currencies.map((currency) => (<MenuItem key={currency} value={currency}>{currency}</MenuItem>))}</Select></FormControl></Grid>
                <Grid item xs={12} sm={6}><TextField fullWidth label="Hesap Tipi" value={bankForm.accountType} onChange={(e) => setBankForm({ ...bankForm, accountType: e.target.value })} /></Grid>
                <Grid item xs={12}><TextField fullWidth label="IBAN (Tam Numara)" value={bankForm.iban} onChange={(e) => setBankForm({ ...bankForm, iban: e.target.value })} placeholder="TR..." /></Grid>
            </Grid>
        </DialogContent>
        <DialogActions>
            <Button onClick={() => setOpenBankDialog(false)}>İptal</Button>
            <Button onClick={handleSaveBankAccount} variant="contained">Kaydet</Button>
        </DialogActions>
      </Dialog>

      {/* --- SNACKBAR --- */}
      <Snackbar open={snackbar.open} autoHideDuration={4000} onClose={() => setSnackbar({ ...snackbar, open: false })}>
        <Alert onClose={() => setSnackbar({ ...snackbar, open: false })} severity={snackbar.severity} sx={{ width: '100%' }}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default CompanyManagement;
