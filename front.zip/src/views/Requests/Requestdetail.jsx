import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import {
  Box,
  Card,
  CardContent,
  CardHeader,
  Typography,
  Grid,
  Divider,
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  Alert,
  CircularProgress
} from '@mui/material';
import { CheckCircle as ApproveIcon, Cancel as RejectIcon, ArrowBack as BackIcon } from '@mui/icons-material';

const getStatusChip = (status) => {
  const statusMap = {
    pending_review: { label: 'Onay Bekliyor', color: 'warning' },
    approved_for_sourcing: { label: 'Satınalmada', color: 'success' },
    rejected: { label: 'Reddedildi', color: 'error' },
  };
  const { label, color } = statusMap[status] || { label: status, color: 'default' };
  return <Chip label={label} color={color} size="small" />;
};

const RequestDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [request, setRequest] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchRequest = async () => {
      if (!id) return;
      setIsLoading(true);
      try {
        const { data } = await axios.get(`/api/talepler/${id}`);
        setRequest(data);
      } catch (error) {
        console.error("Talep detayı çekilirken hata:", error);
        setRequest(null);
      } finally {
        setIsLoading(false);
      }
    };
    fetchRequest();
  }, [id]);

  const handleUpdateRequestStatus = async (newStatus) => {
    try {
      const { data } = await axios.put(`/api/talepler/${id}/status`, { status: newStatus });
      setRequest(data); // Arayüzü backend'den dönen güncel veriyle yenile
    } catch (error) {
      console.error("Durum güncellenirken hata oluştu:", error);
    }
  };

  if (isLoading) {
    return <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}><CircularProgress /></Box>;
  }

  if (!request) {
    return <Alert severity="error">Talep bulunamadı veya ID geçersiz.</Alert>;
  }

  return (
    <Box sx={{ p: 3 }}>
      <Button startIcon={<BackIcon />} onClick={() => navigate(-1)} sx={{ mb: 2 }}>
        Geri Dön
      </Button>
      <Card>
        <CardHeader
          title={`Talep Detayı: #${request.talepNo || request.id}`}
          action={getStatusChip(request.status)}
        />
        <CardContent>
          <Grid container spacing={3}>
            {/* Sol Taraf: Talep Bilgileri */}
            <Grid item xs={12} md={6}>
              <Typography variant="h6" gutterBottom>Talep Bilgileri</Typography>
              <Typography variant="body1"><strong>Başlık:</strong> {request.talepBasligi}</Typography>
              <Typography variant="body1"><strong>Açıklama:</strong> {request.aciklama || 'Yok'}</Typography>
              <Typography variant="body1"><strong>Öncelik:</strong> {request.oncelik}</Typography>
              <Typography variant="body1"><strong>Tarih:</strong> {new Date(request.createdAt).toLocaleString('tr-TR')}</Typography>
              <Divider sx={{ my: 2 }} />
              <Typography variant="h6" gutterBottom>Talep Eden</Typography>
              <Typography variant="body1"><strong>Ad Soyad:</strong> {request.talepSahibiAd}</Typography>
              <Typography variant="body1"><strong>Departman:</strong> {request.isEmriAcanDepartman}</Typography>
              <Typography variant="body1"><strong>Şirket:</strong> {request.firma}</Typography>
            </Grid>

            {/* Sağ Taraf: Onay İşlemleri */}
            <Grid item xs={12} md={6}>
              <Paper variant="outlined" sx={{ p: 2 }}>
                <Typography variant="h6" gutterBottom>Onay İşlemleri</Typography>
                {request.status === 'pending_review' ? (
                  <Box>
                    <Typography variant="body2" sx={{ mb: 2 }}>
                      Lütfen talep edilen ürünleri ve bilgileri kontrol ettikten sonra onaylayın veya reddedin.
                    </Typography>
                    <Box sx={{ display: 'flex', gap: 2 }}>
                      <Button
                        variant="contained"
                        color="success"
                        startIcon={<ApproveIcon />}
                        onClick={() => handleUpdateRequestStatus('approved_for_sourcing')}
                      >
                        Onayla ve Satınalmaya Gönder
                      </Button>
                      <Button
                        variant="contained"
                        color="error"
                        startIcon={<RejectIcon />}
                        onClick={() => handleUpdateRequestStatus('rejected')}
                      >
                        Reddet
                      </Button>
                    </Box>
                  </Box>
                ) : (
                  <Alert severity="info">Bu talep için onay işlemi tamamlanmıştır.</Alert>
                )}
              </Paper>
            </Grid>

            {/* Alt Kısım: Ürün Listesi */}
            <Grid item xs={12}>
              <Typography variant="h6" gutterBottom sx={{ mt: 2 }}>Talep Edilen Ürünler</Typography>
              <TableContainer component={Paper}>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Ürün Adı</TableCell>
                      <TableCell>Marka/Model</TableCell>
                      <TableCell align="right">Miktar</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {request.urunler && request.urunler.map((product) => (
                      <TableRow key={product.id}>
                        <TableCell>{product.urunAdi}</TableCell>
                        <TableCell>{product.marka || ''} {product.model || ''}</TableCell>
                        <TableCell align="right">{product.miktar} {product.birim}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </Grid>
          </Grid>
        </CardContent>
      </Card>
    </Box>
  );
};

export default RequestDetail;