import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import {
  Box,
  Card,
  CardContent,
  CardHeader,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  Button,
  TablePagination,
  Alert,
  CircularProgress
} from '@mui/material';
import { Visibility as ViewIcon, HourglassEmpty, CheckCircle, Cancel } from '@mui/icons-material';

const getStatusChip = (status) => {
  const statusMap = {
    pending_review: { label: 'Onay Bekliyor', color: 'warning', icon: <HourglassEmpty /> },
    approved_for_sourcing: { label: 'Satınalmada', color: 'success', icon: <CheckCircle /> },
    offer_selected: { label: 'Teklif Seçildi', color: 'primary', icon: <CheckCircle /> },
    rejected: { label: 'Reddedildi', color: 'error', icon: <Cancel /> },
    taslak: { label: 'Taslak', color: 'default' }
  };
  const { label, color, icon } = statusMap[status] || { label: status, color: 'default', icon: null };
  return <Chip label={label} color={color} icon={icon} size="small" />;
};

const RequestList = () => {
  const [requests, setRequests] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchRequests = async () => {
      setIsLoading(true);
      try {
        const { data } = await axios.get('/api/talepler');
        setRequests(data);
      } catch (error) {
        console.error("Talepler çekilirken hata:", error);
      } finally {
        setIsLoading(false);
      }
    };
    fetchRequests();
  }, []);

  const handleChangePage = (event, newPage) => { setPage(newPage); };
  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };
  
  const handleViewDetails = (requestId) => {
    // OfferManagement sayfasına yönlendirme. Eğer talep onaylanmamışsa detay sayfasına yönlendirilebilir.
    const request = requests.find(r => r.id === requestId);
    if (request && request.status === 'approved_for_sourcing' || request.status === 'offer_selected') {
        navigate(`/offer-management/request/${requestId}`);
    } else {
        navigate(`/requests/detail/${requestId}`);
    }
  };

  if (isLoading) return <Box sx={{ display: 'flex', justifyContent: 'center', p: 4 }}><CircularProgress /></Box>;

  const paginatedRequests = requests.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  return (
    <Box sx={{ p: 3 }}>
      <Card>
        <CardHeader title="Tüm Talepler" />
        <CardContent>
          {requests.length === 0 ? (
            <Alert severity="info">Gösterilecek bir talep bulunmuyor.</Alert>
          ) : (
            <Paper>
              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Talep No</TableCell>
                      <TableCell>Başlık</TableCell>
                      <TableCell>Firma</TableCell>
                      <TableCell>Tarih</TableCell>
                      <TableCell>Durum</TableCell>
                      <TableCell align="right">İşlemler</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {paginatedRequests.map((req) => (
                      <TableRow key={req.id} hover>
                        <TableCell>#{req.talepNo || req.id}</TableCell>
                        <TableCell>{req.talepBasligi}</TableCell>
                        <TableCell>{req.firma}</TableCell>
                        <TableCell>{new Date(req.createdAt).toLocaleDateString('tr-TR')}</TableCell>
                        <TableCell>{getStatusChip(req.status)}</TableCell>
                        <TableCell align="right">
                          <Button variant="outlined" size="small" startIcon={<ViewIcon />} onClick={() => handleViewDetails(req.id)}>
                            Detay
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
              <TablePagination
                rowsPerPageOptions={[5, 10, 25]}
                component="div"
                count={requests.length}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
                labelRowsPerPage="Sayfa başına satır:"
              />
            </Paper>
          )}
        </CardContent>
      </Card>
    </Box>
  );
};

export default RequestList;