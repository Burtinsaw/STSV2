// src/utils/axios.js
import axios from 'axios';

// API Base URL
const API_BASE_URL = 'http://localhost:5000';

// Axios instance oluştur
const axiosInstance = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000, // 10 saniye timeout
  withCredentials: true, // Cookie'leri gönder
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  }
} );

// Request interceptor - Her istekte token ekle
axiosInstance.interceptors.request.use(
  (config) => {
    // Local storage'dan token al
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    
    console.log(`API Request: ${config.method?.toUpperCase()} ${config.url}`);
    return config;
  },
  (error) => {
    console.error('Request Error:', error);
    return Promise.reject(error);
  }
);

// Response interceptor - Hata yönetimi
axiosInstance.interceptors.response.use(
  (response) => {
    console.log(`API Response: ${response.status} ${response.config.url}`);
    return response;
  },
  (error) => {
    console.error('API Error:', error);
    
    // 401 Unauthorized - Token geçersiz
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    
    // 403 Forbidden - Yetki yok
    if (error.response?.status === 403) {
      console.error('Yetki hatası: Bu işlem için yetkiniz yok');
    }
    
    // 500 Server Error
    if (error.response?.status >= 500) {
      console.error('Sunucu hatası: Lütfen daha sonra tekrar deneyin');
    }
    
    return Promise.reject(error);
  }
);

export default axiosInstance;
