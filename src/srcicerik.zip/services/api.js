// src/services/api.js
import axiosInstance from '../utils/axios';

// ==================== AUTH SERVICES ====================
export const authAPI = {
  // Giriş yap
  login: async (credentials) => {
    const response = await axiosInstance.post('/api/auth/login', credentials);
    return response.data;
  },
  
  // Çıkış yap
  logout: async () => {
    const response = await axiosInstance.post('/api/auth/logout');
    return response.data;
  },
  
  // Kullanıcı bilgilerini al
  getProfile: async () => {
    const response = await axiosInstance.get('/api/auth/profile');
    return response.data;
  },
  
  // Şifre değiştir
  changePassword: async (passwordData) => {
    const response = await axiosInstance.post('/api/auth/change-password', passwordData);
    return response.data;
  }
};

// ==================== DASHBOARD SERVICES ====================
export const dashboardAPI = {
  // Dashboard istatistiklerini al
  getStats: async () => {
    const response = await axiosInstance.get('/api/dashboard/stats');
    return response.data;
  },
  
  // Son aktiviteleri al
  getRecentActivities: async () => {
    const response = await axiosInstance.get('/api/dashboard/activities');
    return response.data;
  },
  
  // Grafik verilerini al
  getChartData: async (chartType) => {
    const response = await axiosInstance.get(`/api/dashboard/charts/${chartType}`);
    return response.data;
  }
};

// ==================== SISTEM SERVICES ====================
export const sistemAPI = {
  // Sistem durumunu kontrol et
  healthCheck: async () => {
    const response = await axiosInstance.get('/health');
    return response.data;
  }
};

// Default export - Tüm API'leri içeren obje
const API = {
  auth: authAPI,
  dashboard: dashboardAPI,
  sistem: sistemAPI
};

export default API;
