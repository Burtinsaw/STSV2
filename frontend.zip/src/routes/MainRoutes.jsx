import React, { lazy } from 'react';
import { Navigate } from 'react-router-dom';

// project import
import MainLayout from 'layout/MainLayout';
import Loadable from 'component/Loadable';

// AUTH CONTEXT
import UserManagement from 'views/Admin/UserManagement';
import { useAuth } from 'contexts/AuthContext';

// Dashboard
const DashboardDefault = Loadable(lazy(() => import('views/Dashboard/Default')));

// Utils
const UtilsTypography = Loadable(lazy(() => import('views/Utils/Typography')));
const SamplePage = Loadable(lazy(() => import('views/SamplePage')));
const ChangePassword = Loadable(lazy(() => import('views/ChangePassword')));

// Request Pages
const UnifiedRequestSystem = Loadable(lazy(() => import('views/Requests/UnifiedRequestSystem')));
const NewRequest = Loadable(lazy(() => import('views/Requests/NewRequest')));
const RequestList = Loadable(lazy(() => import('views/Requests/RequestList')));
const PendingRequests = Loadable(lazy(() => import('views/Requests/PendingRequests')));
const ApprovedRequests = Loadable(lazy(() => import('views/Requests/ApprovedRequests')));

// Procurement Pages
const QuotationComparison = Loadable(lazy(() => import('views/Procurement/QuotationComparison')));

// Company Management
const CompanyManagement = Loadable(lazy(() => import('views/Admin/CompanyManagement')));

// PROTECTED LAYOUT
const ProtectedLayout = () => {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div style={{ 
        display: 'flex', 
        justifyContent: 'center', 
        alignItems: 'center', 
        height: '100vh' 
      }}>
        <div>Yükleniyor...</div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return <MainLayout />;
};

// ==============================|| MAIN ROUTES ||============================== //

const MainRoutes = {
  path: '/',
  element: <ProtectedLayout />,
  children: [
    // Dashboard Routes
    {
      path: '/',
      element: <DashboardDefault />
    },
    {
      path: '/dashboard',
      element: <DashboardDefault />
    },
    {
      path: '/dashboard/default',
      element: <DashboardDefault />
    },
    
    // Auth Routes
    {
      path: '/change-password',
      element: <ChangePassword />
    },
    {
      path: '/first-login',
      element: <ChangePassword isFirstLogin={true} />
    },
    
    // Request Routes
    {
      path: '/requests/unified',
      element: <UnifiedRequestSystem />
    },
    {
      path: '/requests/new',
      element: <NewRequest />
    },
    {
      path: '/requests/list',
      element: <RequestList />
    },
    {
      path: '/requests/pending',
      element: <PendingRequests />
    },
    {
      path: '/requests/approved',
      element: <ApprovedRequests />
    },
    
    // Procurement Routes
    {
      path: '/procurement/quotations',
      element: <QuotationComparison />
    },
    
    // Admin Routes
    {
      path: '/admin/user-management',
      element: <UserManagement />
    },
    {
      path: '/admin/company-management',
      element: <CompanyManagement />
    },
    
    // Utils Routes
    { path: '/utils/util-typography', element: <UtilsTypography /> },
    { path: '/sample-page', element: <SamplePage /> }
  ]
};

export default MainRoutes;
